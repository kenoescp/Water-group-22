# AquaSignal

A responsive, dependency-free European drought outlook for city and water-management teams.

## Run locally

Open `index.html` in a browser, or run `python3 -m http.server` from this folder. The app calls the public Open-Meteo APIs directly from the browser; no API key is required.

## Data and limitations

The dashboard uses Open-Meteo geocoding and forecast data. Its 0–99 drought signal is an explainable screening heuristic: forecast rainfall versus reference evapotranspiration, adjusted for mean temperature. It is not an official drought declaration and should be checked against local reservoirs, groundwater, river flow, soil moisture, basin restrictions, and national authorities before operational decisions.

## GitHub Pages

Because this is static HTML/CSS/JavaScript, it can be published with GitHub Pages from the repository's `main` branch and root directory.
